'use strict'
const { Firestore } = require('@google-cloud/firestore');
const { v4: uuidv4 } = require('uuid');
const excelToJson = require('convert-excel-to-json');

const db = new Firestore();

async function main() {
  const resultReadExcel = excelToJson({ sourceFile: './produtos_cm.xlsx' });
  console.log(resultReadExcel, resultReadExcel.consultas)
  const results = resultReadExcel.consultas
  let batch = db.batch();
  results.forEach((result) => {
    const uuid = uuidv4();
    let str = result.A.toLowerCase().replace(/consulta\s/, '');
    let product = str[0].toUpperCase() + str.substr(1);
    console.log(result)
    let mountObj = {
      serviceId: uuid,
      name: product,
      description: `Consulta presencial de ${product}`,
      partnerId: 1,
      partner: 'Dr. Consulta',
      price: (result.C).toFixed(2),
      scheduled: result.D === 'S' ? true : false,
      active: true,
      phone: '4090-1510',
      redirectUrl: 'https://drconsulta.com/agendamento/consultas',
      createdAt: new Date().toISOString()
    }
    console.log(mountObj)
    let ref = db.collection("consult-services").doc(uuid)
    batch.set(ref, mountObj);
  });
  await batch.commit();
  return console.log("itens cadastrados com suceso!")
}
main();